﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using BoboNext.Data;
using BoboNext.Data.Repository;
using BoboNext.Services.Services;
using Ninject;


namespace BoboNext.Infrastructure
{
    public class BoboNextNinjectModule : IDependencyResolver//NinjectModule
    {
        private readonly IKernel _kernel;
        public BoboNextNinjectModule()
        {
            _kernel = new StandardKernel();
            AddBindings();
        }

        private void AddBindings()
        {
            _kernel.Bind<IDatabaseContext>().To<DatabaseContext>();

            _kernel.Bind<ICityRepository>().To<CityRepository>();
            _kernel.Bind<IUniversityRepository>().To<UniversityRepository>();
            _kernel.Bind<ICathedraRepository>().To<CathedraRepository>();
            _kernel.Bind<IFacultyRepository>().To<FacultyRepository>();
            _kernel.Bind<ISpecialityRepository>().To<SpecialityRepository>();
            _kernel.Bind<IGroupRepository>().To<GroupRepository>();
            _kernel.Bind<ITeacherRepository>().To<TeacherRepository>();
            _kernel.Bind<IStudentRepository>().To<StudentRepository>();
            _kernel.Bind<ILogsRepository>().To<LogsRepository>();
            _kernel.Bind<IAccountRepository>().To<AccountRepository>();
            _kernel.Bind<ITermRepository>().To<TermRepository>();
            _kernel.Bind<IClassRoomRepository>().To<ClassRoomRepository>();
            _kernel.Bind<ISubjectRepository>().To<SubjectRepository>();
            _kernel.Bind<ILessonRepository>().To<LessonRepository>();
            _kernel.Bind<IScheduleRepository>().To<ScheduleRepository>();

            _kernel.Bind<IRoleRepository>().To<RoleRepository>();


            _kernel.Bind<ILogItemsService>().To<LogItemsService>();
            _kernel.Bind<ITermService>().To<TermService>();
            _kernel.Bind<ILessonService>().To<LessonService>();
            _kernel.Bind<IScheduleService>().To<ScheduleService>();

        }

        public object GetService(Type serviceType)
        {
            return _kernel.TryGet(serviceType);
        }
        public IEnumerable<object> GetServices(Type serviceType)
        {
            return _kernel.GetAll(serviceType);
        }

    }
}
