﻿using System.Net.Mail;
using System.Threading.Tasks;
using BoboNext.Core.Domain.Authorize;
using BoboNext.Data;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;

namespace BoboNext.Authorize.Managers
{
    public class ApplicationUserManager : UserManager<Account>
    {
        public ApplicationUserManager(IUserStore<Account> store) : base(store)
        {
        }

        public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options,
            IOwinContext context)
        {
            DatabaseContext dbContext = context.Get<DatabaseContext>();
            ApplicationUserManager manager = new ApplicationUserManager(new UserStore<Account>(dbContext));

            // Configure validation logic for usernames
            manager.UserValidator = new UserValidator<Account>(manager)
            {
                AllowOnlyAlphanumericUserNames = false
            };
            // Configure validation logic for passwords
            manager.PasswordValidator = new PasswordValidator
            {
                RequiredLength = 6,
                //RequireNonLetterOrDigit = true,
                //RequireDigit = true,
                //RequireLowercase = true,
                //RequireUppercase = true
            };

            manager.EmailService = new EmailService();

            return manager;
        }
    }

    public class EmailService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // настройка логина, пароля отправителя
            const string @from = "rozklad.ua@yandex.ru"; //todo: add email "from" and "pass"
            const string pass = "Rozklad123";
            //ответ на вопрос:123456

            // адрес и порт smtp-сервера, с которого мы и будем отправлять письмо
            var client = new SmtpClient("smtp.yandex.ru")
            {
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new System.Net.NetworkCredential(@from, pass),
                EnableSsl = true
            };

            // создаем письмо: message.Destination - адрес получателя
            var mail = new MailMessage(from, message.Destination)
            {
                Subject = message.Subject,
                Body = message.Body
            };

            return client.SendMailAsync(mail);
        }
    }
}
