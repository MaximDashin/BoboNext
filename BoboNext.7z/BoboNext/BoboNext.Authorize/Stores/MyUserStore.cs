﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoboNext.Core;
using BoboNext.Data;
using Microsoft.AspNet.Identity;

namespace BoboNext.Authorize.Stores
{
    class MyUserStore<TUser, TRole> :
        IUserRoleStore<TUser, Guid>,
        IUserPasswordStore<TUser, Guid>,
        IUserLockoutStore<TUser, Guid>,
        IUserTwoFactorStore<TUser, Guid>,
        IUserSecurityStampStore<TUser, Guid>,
        IQueryableUserStore<TUser, Guid>,
        IUserEmailStore<TUser, Guid>,
        IUserPhoneNumberStore<TUser, Guid>
        where TUser : Account
         where TRole : Role
    {
        private EntityStore<TUser> _userStore;
        private EntityStore<TRole> _roleStore;
        public DatabaseContext Context { get; private set; }

        public MyUserStore(DatabaseContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            Context = context;
            _userStore = new EntityStore<TUser>(context);
            _roleStore = new EntityStore<TRole>(context);
        }


        public IQueryable<TUser> Users => _userStore.EntitySet;


        #region IUserStore

        public Task CreateAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            _userStore.Create(user);
            Context.SaveChanges();

            return Task.FromResult(0);
        }

        public Task DeleteAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            _userStore.Delete(user);
            Context.SaveChanges();

            return Task.FromResult(0);
        }

        public Task UpdateAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            _userStore.Update(user);
            Context.SaveChanges();

            return Task.FromResult(0);
        }

        public Task<TUser> FindByIdAsync(Guid userId)
        {
            //return _userStore.GetByIdAsync(userId);
            return _userStore.DbEntitySet.FirstOrDefaultAsync(e => e.Id == userId); // todo:спросить
            //return Users.FirstOrDefaultAsync(e => e.Id == userId);
        }

        public Task<TUser> FindByNameAsync(string userName)
        {
            return _userStore.DbEntitySet.FirstOrDefaultAsync(e => e.UserName == userName);
        }

        public void Dispose()
        {
            Context?.Dispose();

            Context = null;
            _userStore = null;
            _roleStore = null;
            
        }

        #endregion

        #region IUserRoleStore

        public Task AddToRoleAsync(TUser user, string roleName)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(roleName))
                throw new ArgumentException("Argument cannot be null or empty: roleName.");

            var roleEntity = _roleStore.DbEntitySet.FirstOrDefault(e => e.Name == roleName);
            if (roleEntity == null)
                throw new NullReferenceException("roleEntity");

            user.Roles.Add(roleEntity);
            roleEntity.Accounts.Add(user);
            return Task.FromResult(0);
        }

        public Task<IList<string>> GetRolesAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            var roles = user.Roles.ToList().Select(e => e.Name).ToList(); //todo: ask

            return Task.FromResult<IList<string>>(roles);
        }

        public Task<bool> IsInRoleAsync(TUser user, string roleName)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(roleName))
                throw new ArgumentException("Argument cannot be null or empty: roleName.");

            var roles = _roleStore.DbEntitySet.Where(r => string.Equals(r.Name, roleName, StringComparison.CurrentCultureIgnoreCase));
            foreach (var role in roles)
            {
                if (role.Accounts.Any(e => e.Id == user.Id))
                {
                    return Task.FromResult(true);
                }
            }
            return Task.FromResult(false);
        }

        public Task RemoveFromRoleAsync(TUser user, string roleName)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(roleName))
                throw new ArgumentException("Argument cannot be null or empty: roleName.");

            var roleEntity = _roleStore.DbEntitySet.FirstOrDefault(e => e.Name == roleName);
            if (roleEntity != null)
                user.Roles.Remove(roleEntity);

            return Task.FromResult(0);
        }

        #endregion

        #region IUserPasswordStore

        public Task SetPasswordHashAsync(TUser user, string passwordHash)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(passwordHash))
                throw new ArgumentException("Argument cannot be null or empty: passwordHash.");

            user.PasswordHash = passwordHash;

            return Task.FromResult(0);
        }

        public Task<string> GetPasswordHashAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult<string>(user.PasswordHash);
        }

        public Task<bool> HasPasswordAsync(TUser user)
        {
            return Task.FromResult(user.PasswordHash != null);
        }


        #endregion

        #region IUserLockoutStore

        public Task<DateTimeOffset> GetLockoutEndDateAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            //return Task.FromResult<DateTimeOffset>(user.LockoutEndDateUtc.Value); // todo:Ask
            return Task.FromResult(user.LockoutEndDateUtc.HasValue
                ? new DateTimeOffset(DateTime.SpecifyKind(user.LockoutEndDateUtc.Value, DateTimeKind.Utc))
                : default(DateTimeOffset));
        }

        public Task SetLockoutEndDateAsync(TUser user, DateTimeOffset lockoutEnd)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (lockoutEnd == null)
                throw new ArgumentException("Argument cannot be null or empty: lockoutEnd.");

            user.LockoutEndDateUtc = (lockoutEnd == DateTimeOffset.MinValue) ? null : new DateTime?(lockoutEnd.UtcDateTime); //todo:ask

            return Task.FromResult(0);
        }

        public Task<int> IncrementAccessFailedCountAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.AccessFailedCount++;
            _userStore.Update(user);
            Context.SaveChanges();

            return Task.FromResult(user.AccessFailedCount);
        }

        public Task ResetAccessFailedCountAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.AccessFailedCount = 0;
            _userStore.Update(user);
            Context.SaveChanges();

            return Task.FromResult(user.AccessFailedCount);
        }

        public Task<int> GetAccessFailedCountAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.AccessFailedCount);
        }

        public Task<bool> GetLockoutEnabledAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.LockoutEnabled);
        }

        public Task SetLockoutEnabledAsync(TUser user, bool enabled)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.LockoutEnabled = enabled;
            _userStore.Update(user);
            Context.SaveChanges();

            return Task.FromResult(0);
        }

        #endregion

        #region IUserTwoFactorStore

        public Task SetTwoFactorEnabledAsync(TUser user, bool enabled)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.TwoFactorEnabled = enabled;
            _userStore.Update(user);
            Context.SaveChanges();

            return Task.FromResult(0);
        }

        public Task<bool> GetTwoFactorEnabledAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.TwoFactorEnabled);
        }

        #endregion

        #region IUserSecurityStampStore

        public Task SetSecurityStampAsync(TUser user, string stamp)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(stamp))
                throw new ArgumentException("Argument cannot be null or empty: stamp.");

            user.SecurityStamp = stamp; //todo:aks context.savechanges

            return Task.FromResult(0);
        }

        public Task<string> GetSecurityStampAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.SecurityStamp);
        }

        #endregion

        #region IUserEmailStore

        public Task SetEmailAsync(TUser user, string email)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(email))
                throw new ArgumentException("Argument cannot be null or empty: email.");

            user.Email = email;

            return Task.FromResult(0);
        }

        public Task<string> GetEmailAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.Email);
        }

        public Task<bool> GetEmailConfirmedAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.EmailConfirmed);
        }

        public Task SetEmailConfirmedAsync(TUser user, bool confirmed)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.EmailConfirmed = confirmed;

            return Task.FromResult(0);
        }

        public Task<TUser> FindByEmailAsync(string email)
        {
            if (string.IsNullOrEmpty(email))
                throw new ArgumentException("Argument cannot be null or empty: email.");

            return Task.FromResult(_userStore.DbEntitySet.FirstOrDefault(e => e.Email.ToLower() == email.ToLower()));
        }

        #endregion

        #region IUserPhoneNumberStore

        public Task SetPhoneNumberAsync(TUser user, string phoneNumber)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            if (string.IsNullOrEmpty(phoneNumber))
                throw new ArgumentException("Argument cannot be null or empty: phoneNumber.");

            user.PhoneNumber = phoneNumber;

            return Task.FromResult(0);
        }

        public Task<string> GetPhoneNumberAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.PhoneNumber);
        }

        public Task<bool> GetPhoneNumberConfirmedAsync(TUser user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return Task.FromResult(user.PhoneNumberConfirmed);
        }

        public Task SetPhoneNumberConfirmedAsync(TUser user, bool confirmed)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.PhoneNumberConfirmed = confirmed;

            return Task.FromResult(0);
        }

        #endregion
    }
}
