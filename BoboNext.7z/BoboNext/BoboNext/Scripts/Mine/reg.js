﻿//$("#none-group").on('click', function () {
//    $(this).hide();
//    $("#reg1").hide();
//    $("#reg2, #none-group-prev").show();
//});
//$("#none-group-prev").on('click', function () {
//    $(this).hide();
//    $("#reg2, #reg3, #reg4").hide();
//    $("#reg1, #none-group").show();
//});
//$("#none-teacher").on('click', function () {
//    $(this).hide();
//    $("#reg5").hide();
//    $("#reg6, #none-teacher-prev").show();
//});
//$("#none-teacher-prev").on('click', function () {
//    $(this).hide();
//    $("#reg6").hide();
//    $("#reg5, #none-teacher").show();
//});

//var universitysource = [
//    { value: "ВНТУ", label: "ВНТУ" },
//    { value: "МО-15", label: "МО-15" },
//    { value: "КІ", label: "КІ" },
//    { value: "КІН", label: "КІН" }
//];
//$(function () {
//    $("#university").autocomplete({
//        source: universitysource,
//        minLength: 0
//    }).click(function () {
//        $(this).autocomplete('search')
//    });
//});

//var groupsource = [
//    { value: "УБ-14", label: "УБ-14" },
//    { value: "МО-15", label: "МО-15" },
//    { value: "КІ", label: "КІ" },
//    { value: "КІН", label: "КІН" }
//];
//$(function () {
//    $("#group").autocomplete({
//        source: groupsource,
//        minLength: 0
//    }).click(function () {
//        $(this).autocomplete('search')
//    });
//});

//var specialsource = [
//    { value: "УБ", label: "УБ" },
//    { value: "МО", label: "МО" },
//    { value: "КІ", label: "КІ" },
//    { value: "КІН", label: "КІН" }
//];
//$(function () {
//    $("#special").autocomplete({
//        source: specialsource,
//        minLength: 0
//    }).click(function () {
//        $(this).autocomplete('search')
//    });
//});

//var facultysource = [
//    { value: "УБ", label: "УБ" },
//    { value: "МО", label: "МО" },
//    { value: "КІ", label: "КІ" },
//    { value: "КІН", label: "КІН" }
//];
//$(function () {
//    $("#faculty").autocomplete({
//        source: facultysource,
//        minLength: 0
//    }).click(function () {
//        $(this).autocomplete('search')
//    });
//});

//var specialsource = [
//    { value: "УБ-14", label: "УБ-14" },
//    { value: "МО-15", label: "МО-15" },
//    { value: "КІ", label: "КІ" },
//    { value: "КІН", label: "КІН" }
//];
//$(function () {
//    $("#special").autocomplete({
//        source: specialsource,
//        minLength: 0
//    }).click(function () {
//        $(this).autocomplete('search')
//    });
//});

//var cafedrasource = [
//    { value: "кафедра", label: "кафедра" },
//    { value: "кафедра", label: "кафедра" },
//    { value: "кафедра3", label: "КІ" },
//    { value: "кафедра2", label: "КІН" }
//];
//$(function () {
//    $("#cafedra").autocomplete({
//        source: cafedrasource,
//        minLength: 0
//    }).click(function () {
//        $(this).autocomplete('search')
//    });
//});