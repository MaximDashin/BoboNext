﻿namespace BoboNext.Core
{
    public enum OptionType
    {
        MailerParameters = 1,
        VkontakteAuthenticationSettings = 2,
        GoogleAuthenticationSettings = 3,
        FacebookAuthenticationSettings = 4,
        LinkedInAuthenticationSettings = 5,
        TwitterAuthenticationSettings = 6,
        InstagramAuthenticationSettings = 7,
        RobokassaConfig = 8,
        RbkMoneyConfig = 9,
        SmscConfig = 10,
        DefaultEditor = 11
    }
}
