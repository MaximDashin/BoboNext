﻿namespace BoboNext.Core
{
    public enum LogMessageType
    {
        Info,
        Warning,
        Fatal,
        Debug,
        Trace
    }
}
