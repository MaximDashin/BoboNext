﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core.Enumerations
{
    public enum LessonType
    {
        [Display(Name = "Лабораторна")]
        Laboratory,
        [Display(Name = "Лекція")]
        Lecture,
        [Display(Name = "Практика")]
        Practice
    }
}
