﻿using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core
{
    public enum TypeOfWeek
    {
        [Display(Name = "Перший")]
        First = 0,
        [Display(Name = "Другий")]
        Second = 1,
        [Display(Name = "Обидва")]
        Both = 2

    }
}
