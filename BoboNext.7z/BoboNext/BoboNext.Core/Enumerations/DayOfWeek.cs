﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core
{
    public enum DayOfWeek
    {
        [Display(Name = "ПН")]
        Monday = 0,
        [Display(Name = "ВТ")]
        Tuesday = 1,
        [Display(Name = "СР")]
        Wednesday = 2,
        [Display(Name = "ЧТ")]
        Thursday = 3,
        [Display(Name = "ПТ")]
        Friday = 4,
        [Display(Name = "СБ")]
        Saturday = 5,
        [Display(Name = "НД")]
        Sunday = 6
    }
}
