﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Claims;
using System.Threading.Tasks;
using BoboNext.Core.Domain.System;
using BoboNext.Core.Domain.University;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace BoboNext.Core.Domain.Authorize
{
    public class Account : IdentityUser
    {
        public bool IsDeleted { get; set; }

        public bool Approve { get; set; }

        public virtual Student Student { get; set; }

        public virtual ICollection<LogItem> LogItems { get; set; }

        public int? TeacherId { get; set; }
        public virtual Teacher Teacher { get; set; }

        public int? FacultyId { get; set; }
        public virtual Faculty Faculty { get; set; }

        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<Account> manager)
        {
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            return userIdentity;
        }

        public override string ToString()
        {
            return $"Login: {UserName}, Email: {Email}";
        }
    }
}