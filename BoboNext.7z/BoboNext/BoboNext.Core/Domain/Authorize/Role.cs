﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace BoboNext.Core.Domain.Authorize
{
    public class Role : IdentityRole /*IRole<Guid>*/
    {
        public string Description { get; set; }

        public bool IsDeleted { get; set; }
    }
}