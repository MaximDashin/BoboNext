﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core.Domain.Lesson
{
    public class Subject
    {
        public Subject()
        {
            Lessons = new HashSet<Lesson>();
        }

        public int SubjectId { get; set; }

        [Required(ErrorMessage = "Поле 'Предмет' обовязкове до заповнення")]
        [Display(Name = "Предмет")]
        public string SubjectName { get; set; }

        public bool IsDeleted { get; set; }

        public virtual ICollection<Lesson> Lessons { get; set; }

        public int UniversityId { get; set; }

        public virtual University.University University { get; set; }


        public override string ToString()
        {
            return $"Назва предмету: {SubjectName}";
        }

    }
}
