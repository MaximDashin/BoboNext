﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BoboNext.Core.Domain.University;
using BoboNext.Core.Enumerations;

namespace BoboNext.Core.Domain.Lesson
{
    public class Lesson
    {
        public Lesson()
        {
            Groups = new HashSet<Group>();
            Schedules = new HashSet<Schedule>();
        }

        public int LessonId { get; set; }

        public bool IsDeleted { get; set; }

        public DayOfWeek DayOfWeek { get; set; }

        public TypeOfWeek TypeOfWeek { get; set; }

        public LessonType LessonType { get; set; }

        public DateTime DateTimeStart { get; set; }

        public DateTime DateTimeEnd { get; set; }

        public int SubGroup { get; set; }

        public int TeacherId { get; set; }

        public virtual Teacher Teacher { get; set; }

        public int SubjectId { get; set; }

        public virtual Subject Subject { get; set; }

        public int ClassRoomId { get; set; }

        public virtual ClassRoom ClassRoom {get; set;}

        public virtual ICollection<Group> Groups { get; set; }

        public virtual ICollection<Schedule> Schedules { get; set; }

        public int UniversityId { get; set; }

        public virtual University.University University { get; set; }


        public override string ToString()
        {
            var enumerable = Groups.Select(@group => @group.GroupName).ToArray();
            var sb = new StringBuilder();
            Array.ForEach(enumerable, x => sb.Append(x + ", "));
            string s = $"Групи: {sb}. День тижня:{Enum.GetName(typeof(DayOfWeek), DayOfWeek)}. Виклдач:{Teacher.TeacherName}. Предмет:{Subject.SubjectName}. ";
       
                s += $"Аудиторія: {ClassRoom.ClassRoomName}";
            return s;
        }
    }
}
