﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BoboNext.Core.Domain.University;

namespace BoboNext.Core.Domain.Lesson
{
    public class Group
    {
        public int GroupId { get; set; }

        [Required(ErrorMessage = "Поле 'Назва групи' обовязкове до заповнення")]
        [Display(Name = "Назва групи")]
        public string GroupName { get; set; }

        public int SpecialityId { get; set; }

        public bool Approve { get; set; }

        public bool IsDeleted { get; set; }

        public virtual Speciality Speciality { get; set; }

        public virtual ICollection<Lesson> Lessons { get; set; }

        public virtual  ICollection<Student> Students { get; set; } 


        public override string ToString()
        {
            return $"Назва групи: {GroupName}";
        }
    }
}
