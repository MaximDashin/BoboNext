﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BoboNext.Core.Domain.Lesson;

namespace BoboNext.Core.Domain.University
{
   public class Speciality
    {
        public Speciality()
        {
            Groups = new HashSet<Group>();
        }

        public int SpecialityId { get; set; }

        [Required(ErrorMessage = "Поле 'Спеціальність' обовязкове до заповнення")]
        [Display(Name = "Спеціальність")]
        public string SpecialityName { get; set; }

        public bool IsDeleted { get; set; }

        public int FacultyId { get; set; }

        public virtual Faculty Faculty { get; set; }

        public virtual ICollection<Group> Groups { get; set; }


        public override string ToString()
        {
            var str = $"Назва: {SpecialityName}, факультет: {Faculty.FacultyName}";
            return str;
        }
    }
}
