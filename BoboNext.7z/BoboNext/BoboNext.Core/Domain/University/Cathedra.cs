﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core.Domain.University
{
    public class Cathedra
    {
        public Cathedra()
        {
            Teachers = new HashSet<Teacher>();
        }
        public int CathedraId { get; set; }

        [Required(ErrorMessage = "Поле 'Кафедра' обовязкове до заповнення")]
        [Display(Name = "Кафедра")]
        public string CathedraName { get; set; }

        public bool IsDeleted { get; set; }

        public int FacultyId { get; set; }

        public virtual Faculty Faculty { get; set; }

        public virtual ICollection<Teacher> Teachers { get; set; }

        public override string ToString()
        {
            return $"Назва кафедри: {CathedraName}";
        }
    }
}
