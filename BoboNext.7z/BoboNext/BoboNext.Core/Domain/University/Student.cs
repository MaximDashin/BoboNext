﻿using System.ComponentModel.DataAnnotations.Schema;
using BoboNext.Core.Domain.Authorize;
using BoboNext.Core.Domain.Lesson;

namespace BoboNext.Core.Domain.University
{
    public class Student
    {
        //public int StudentId { get; set; }

        //public bool IsDeleted { get; set; }

        public int GroupId { get; set; }
        public virtual Group Group { get; set; }

        public string AccountId { get; set; }
        public virtual Account Account { get; set; }
    }
}
