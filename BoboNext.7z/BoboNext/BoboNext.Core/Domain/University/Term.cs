﻿using System;

namespace BoboNext.Core.Domain.University
{
    public class Term
    {
        public int TermId { get; set; }

        public bool IsDeleted { get; set; }

        public int UniversityId { get; set; }

        public virtual University University { get; set; }

        public DateTime Start { get; set; }

        public DateTime End { get; set; }

        public TypeOfWeek StartTypeWeek { get; set; }
    }
}
