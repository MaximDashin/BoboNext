﻿using BoboNext.Core.Domain.Authorize;

namespace BoboNext.Core.Domain.University
{
    public class Deanery
    {
        public int DeaneryId { get; set; }

        public int FacultyId { get; set; }
        public Faculty Faculty { get; set; }

        //public string AccountId { get; set; }
        public Account Account { get; set; }

        public bool IsDeleted { get; set; }
    }
}