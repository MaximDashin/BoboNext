﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core.Domain.University
{
   public class City
    {
        public City()
        {
            Universities = new HashSet<University>();
        }

        public int CityId { get; set; }

        [Required(ErrorMessage = "Поле 'Місто' обовязкове до заповнення")]
        [Display(Name = "Місто")]
        public string CityName { get; set; }

        public bool IsDeleted { get; set; }

        [Required(ErrorMessage = "Поле 'Довгота' обовязкове до заповнення")]
        [Display(Name = "Довгота")]
        public string Longitude { get; set; } //долгота

        [Required(ErrorMessage = "Поле 'Широта' обовязкове до заповнення")]
        [Display(Name = "Широта")]
        public string Latitude { get; set; } //широта

        public virtual ICollection<University> Universities { get; set; }
    }
}
