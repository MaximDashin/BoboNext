﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using BoboNext.Core.Domain.Authorize;
using BoboNext.Core.Domain.Lesson;

namespace BoboNext.Core.Domain.University
{
    public class University
    {
        public University()
        {
            Faculties = new HashSet<Faculty>();
            Terms = new HashSet<Term>();
            ClassRooms = new HashSet<ClassRoom>();
            Schedules = new HashSet<Schedule>();
            Subjects = new HashSet<Subject>();
        }

        public int UniversityId { get; set; }

        [Required(ErrorMessage = "Поле 'Університет' обовязкове до заповнення")]
        [Display(Name = "Університет")]
        public string UniversityName { get; set; }

        public bool IsDeleted { get; set; }

        public int CityId { get; set; }

        public virtual City City { get; set; }

        public virtual ICollection<Schedule> Schedules { get; set; }

        public virtual ICollection<Faculty> Faculties { get; set; }

        public virtual ICollection<Term> Terms { get; set; }

        public virtual ICollection<ClassRoom> ClassRooms { get; set; }

        public virtual ICollection<Subject> Subjects { get; set; }

        public virtual ICollection<Lesson.Lesson> Lessons { get; set; }
    }
}
