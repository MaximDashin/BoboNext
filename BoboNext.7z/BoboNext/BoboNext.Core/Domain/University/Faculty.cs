﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BoboNext.Core.Domain.Authorize;

namespace BoboNext.Core.Domain.University
{
    public class Faculty
    {
        //public Faculty()
        //{
        //    Specialities = new HashSet<Speciality>();
        //}

        public int FacultyId { get; set; }

        [Required(ErrorMessage = "Поле 'Факультет' обовязкове до заповнення")]
        [Display(Name = "Факультет")]
        public string FacultyName { get; set; }

        public bool IsDeleted { get; set; }

        public int UniversityId { get; set; }

        public virtual University University { get; set; }

        public virtual ICollection<Speciality> Specialities { get; set; }

        public string AccountId { get; set; }
        public virtual Account Account { get; set; }

        public virtual ICollection<Cathedra> Cathedras { get; set; }


        public override string ToString()
        {
            return $"Назва факультету: {FacultyName}";
        }
    }
}
