﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core.Domain.University
{
    public class ClassRoom
    {
        public ClassRoom()
        {
            Lessons = new HashSet<Lesson.Lesson>();
        }

        public int ClassRoomId { get; set; }

        [Required(ErrorMessage = "Поле 'Аудиторія' обовязкове до заповнення")]
        [Display(Name = "Аудиторія")]
        public string ClassRoomName { get; set; }

        public int UniversityId { get; set; }

        public bool IsDeleted { get; set; }

        public virtual University University { get; set; }

        public virtual ICollection<Lesson.Lesson> Lessons {get; set;}


        public override string ToString()
        {
            return $"Номер аудиторії: {ClassRoomName}";
        }
    }
}
