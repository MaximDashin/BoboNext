﻿using System;
using System.Collections.Generic;

namespace BoboNext.Core.Domain.University
{
    public class Schedule
    {
        public int ScheduleId { get; set; }

        public int ScheduleNumber { get; set; }

        public bool IsDeleted { get; set; }

        public DateTime StartLesson { get; set; }

        public DateTime EndLesson { get; set; }

        public int UniversityId { get; set; }

        public virtual University University { get; set; }

        public virtual ICollection<Lesson.Lesson> Lessons { get; set; }


        public override string ToString()
        {
            return $"Номер уроку {ScheduleNumber}: ({StartLesson.ToShortTimeString()} - {EndLesson.ToShortTimeString()})";
        }
    }
}
