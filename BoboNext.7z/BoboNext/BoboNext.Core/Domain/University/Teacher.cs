﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BoboNext.Core.Domain.Authorize;

namespace BoboNext.Core.Domain.University
{
    public class Teacher
    {
        //public Teacher()
        //{
        //    Lessons = new HashSet<Lesson>();
        //}

        public int TeacherId { get; set; }

        [Required(ErrorMessage = "Поле 'ПІБ викладача' обовязкове до заповнення")]
        [Display(Name = "ПІБ викладача")]
        public string TeacherName { get; set; }

        public bool IsDeleted { get; set; }

        public int CathedraId { get; set; }

        public virtual Cathedra Cathedra { get; set; }

        public string AccountId { get; set; }
        public virtual Account Account { get; set; }

        public virtual ICollection<Lesson.Lesson> Lessons { get; set; }

        public bool Approve { get; set; }


        public override string ToString()
        {

            return $"Ім'я викладача: {TeacherName}";
        }
    }
}
