﻿using System;
using BoboNext.Core.Domain.Authorize;

namespace BoboNext.Core.Domain.System
{
    public class LogItem
    {
        public LogItem()
        {
            DateCreate = DateTime.Now;
        }

        public int LogItemId { get; set; }

        public string Description { get; set; }

        public string NameObject { get; set; }

        public DateTime DateCreate { get; set; }

        public string AccountId { get; set; }

        public virtual Account Account { get; set; }
    }
}