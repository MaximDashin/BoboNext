﻿using System.ComponentModel.DataAnnotations;

namespace BoboNext.Core.ViewModels
{
    public class RegistrationViewModel
    {
        public string AccountId { get; set; }

        [Required(ErrorMessage = "Поле Email обов'язкове")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Поле 'Пароль' обов'язкове")]
        [MinLength(6, ErrorMessage = "Пароль повинен містити не менше 6-ти символів")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Поле 'Підтвердження паролю' обов'язкове")]
        [Compare("Password", ErrorMessage = "Пароль та підтвердження паролю не співпадають")]
        [DataType(DataType.Password)]
        public string PasswordAgain { get; set; }

        public int CityId { get; set; }

        public int UniversityId { get; set; }

        public int CathedraId { get; set; }

        public int FacultyId { get; set; }

        public int GroupId { get; set; }

        public int TeacherId { get; set; }

        public int TypeRegister { get; set; }
    }
}