﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoboNext.Core.Domain.University;

namespace BoboNext.Core.ViewModels
{
    public class ScheduleViewModel
    {
        public int ScheduleId { get; set; }

        [Required(ErrorMessage = "Поле 'Номер уроку' обовязкове до заповнення")]
        [Display(Name = "Номер уроку")]
        public int ScheduleNumber { get; set; }

        public string StartLessonTime { get; set; }

        public string EndLessonTime { get; set; }

        public int UniversityId { get; set; }

        public virtual University University { get; set; }
    }
}
