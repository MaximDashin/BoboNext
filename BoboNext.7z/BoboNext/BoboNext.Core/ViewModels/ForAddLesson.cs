﻿using System;
using System.Collections.Generic;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.Domain.University;
using BoboNext.Core.Enumerations;

namespace BoboNext.Core.ViewModels
{
    public class ForAddLesson
    {
        public int LessonId { get; set; } //todo: сделать валидацию

        public int UniversityId { get; set; }

        public int[] SelectedGroupIds { get; set; }

        public ICollection<Group> Groups { get; set; }

        public int SubjectId { get; set; }

        public int TeacherId { get; set; }

        public int[] SelectedScheduleIds { get; set; }

        public ICollection<Schedule> Schedules { get; set; }

        public int ClassRoomId { get; set; }

        public DayOfWeek DayOfWeek { get; set; }

        public TypeOfWeek TypeOfWeek { get; set; }

        public string DateStart { get; set; }
        public string DateEnd { get; set; }

        public string SubGroup { get; set; }
        public LessonType TypeOfLesson { get; set; }
    }

}