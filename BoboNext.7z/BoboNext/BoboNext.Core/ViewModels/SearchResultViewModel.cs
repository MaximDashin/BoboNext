﻿using System.Collections.Generic;
using System.Linq;

namespace BoboNext.Core.ViewModels
{
    public class SearchResultViewModel
    {
        public List<UniversityVm> Universities { get; set; } 
        public List<CathedraVm> Cathedras { get; set; } 
        public List<SpecialityVm> Specialities { get; set; }

        public int ResultCount => Universities.Count() + Cathedras.Count() + Specialities.Count();
    }

    public class UniversityVm
    {
        public int CityId { get; set; }
        public int UniversityId { get; set; }
        public string UniversityName { get; set; }
    }
    public class CathedraVm
    {
        public int CityId { get; set; }
        public int UniversityId { get; set; }
        public int CathedraId { get; set; }
        public string CathedraName { get; set; }
    }
    public class SpecialityVm
    {
        public int CityId { get; set; }
        public int UniversityId { get; set; }
        public int SpecialityId { get; set; }
        public string SpecialityName { get; set; }
    }
}
