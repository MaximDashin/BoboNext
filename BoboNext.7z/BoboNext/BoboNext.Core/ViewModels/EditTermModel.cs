﻿using System;
using System.ComponentModel.DataAnnotations;
using BoboNext.Core.Domain.University;

namespace BoboNext.Core.ViewModels
{
    public class EditTermModel
    {
        public int TermId { get; set; }

        [Required(ErrorMessage = "Поле 'Дата початку' обовязкове до заповнення")]
        [Display(Name = "Дата початку")]
        public string Start { get; set; }

        [Required(ErrorMessage = "Поле 'Дата завершення' обовязкове до заповнення")]
        [Display(Name = "Дата завершення")]
        public string End { get; set; }

        [Required(ErrorMessage = "Поле 'Початковий тиждень' обовязкове до заповнення")]
        [Display(Name = "Початковий тиждень")]
        public TypeOfWeek StartTypeWeek { get; set; }

        public int UniversityId { get; set; }
        public University University { get; set; }
    }
}