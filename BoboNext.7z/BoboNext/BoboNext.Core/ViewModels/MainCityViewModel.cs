﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoboNext.Core.ViewModels
{
    public class MainCityViewModel
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public IEnumerable<MainUniversityViewModel> Universities { get; set; }
    }
}
