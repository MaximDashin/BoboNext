using System.Linq;
using BoboNext.Core.Domain.Authorize;
using Microsoft.AspNet.Identity.EntityFramework;

namespace BoboNext.Data.Migrations
{
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<DatabaseContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(DatabaseContext context)
        {
            context.Roles.AddOrUpdate(p => p.Name,
                new Role {Name = "Admin", Description = "������������"},
                new Role {Name = "Teacher", Description = "��������"},
                new Role {Name = "Deanery", Description = "�������"},
                new Role {Name = "Student", Description = "�������"}
                );
            //var role = context.Roles.First(e => e.Name == "Admin");
            //context.Users.AddOrUpdate(p => p.Email,
            //    new Account { Email = "admin@admin.ua",
            //        Id = "8d2d9633-0bd8-4706-afab-b0f340d16ed9",
            //        PasswordHash = "AP5Q2LFahPaSA6wCr7JXILinDNW7TRix69IFScdITSVu/MZaKY/3M87GPV+ouq8GZw==",
            //        SecurityStamp = "86a3c2b8-883d-47a8-b83c-d603ac4c12f3",
            //        Approve = true,
            //        EmailConfirmed = true,
            //        AccessFailedCount = 0,
            //        UserName = "admin@admin.ua",
            //        Roles = {new IdentityUserRole {UserId = "8d2d9633-0bd8-4706-afab-b0f340d16ed9", RoleId = role.Id}}}
            //    );
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
        }
    }
}
