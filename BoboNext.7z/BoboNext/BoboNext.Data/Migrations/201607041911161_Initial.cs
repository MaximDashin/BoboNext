namespace BoboNext.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cathedras",
                c => new
                    {
                        CathedraId = c.Int(nullable: false, identity: true),
                        CathedraName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        FacultyId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CathedraId)
                .ForeignKey("dbo.Faculties", t => t.FacultyId)
                .Index(t => t.FacultyId);
            
            CreateTable(
                "dbo.Faculties",
                c => new
                    {
                        FacultyId = c.Int(nullable: false, identity: true),
                        FacultyName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        UniversityId = c.Int(nullable: false),
                        AccountId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.FacultyId)
                .ForeignKey("dbo.Universities", t => t.UniversityId)
                .ForeignKey("dbo.AspNetUsers", t => t.AccountId)
                .Index(t => t.UniversityId)
                .Index(t => t.AccountId);
            
            CreateTable(
                "dbo.AspNetUsers",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        IsDeleted = c.Boolean(nullable: false),
                        Approve = c.Boolean(nullable: false),
                        TeacherId = c.Int(),
                        FacultyId = c.Int(),
                        Email = c.String(maxLength: 256),
                        EmailConfirmed = c.Boolean(nullable: false),
                        PasswordHash = c.String(),
                        SecurityStamp = c.String(),
                        PhoneNumber = c.String(),
                        PhoneNumberConfirmed = c.Boolean(nullable: false),
                        TwoFactorEnabled = c.Boolean(nullable: false),
                        LockoutEndDateUtc = c.DateTime(),
                        LockoutEnabled = c.Boolean(nullable: false),
                        AccessFailedCount = c.Int(nullable: false),
                        UserName = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Faculties", t => t.FacultyId)
                .ForeignKey("dbo.Teachers", t => t.TeacherId)
                .Index(t => t.TeacherId)
                .Index(t => t.FacultyId)
                .Index(t => t.UserName, unique: true, name: "UserNameIndex");
            
            CreateTable(
                "dbo.AspNetUserClaims",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        ClaimType = c.String(),
                        ClaimValue = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.AspNetUserLogins",
                c => new
                    {
                        LoginProvider = c.String(nullable: false, maxLength: 128),
                        ProviderKey = c.String(nullable: false, maxLength: 128),
                        UserId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.LogItems",
                c => new
                    {
                        LogItemId = c.Int(nullable: false, identity: true),
                        Description = c.String(),
                        NameObject = c.String(),
                        DateCreate = c.DateTime(nullable: false),
                        AccountId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.LogItemId)
                .ForeignKey("dbo.AspNetUsers", t => t.AccountId)
                .Index(t => t.AccountId);
            
            CreateTable(
                "dbo.AspNetUserRoles",
                c => new
                    {
                        UserId = c.String(nullable: false, maxLength: 128),
                        RoleId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.UserId, t.RoleId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.Students",
                c => new
                    {
                        AccountId = c.String(nullable: false, maxLength: 128),
                        GroupId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.AccountId)
                .ForeignKey("dbo.Groups", t => t.GroupId)
                .ForeignKey("dbo.AspNetUsers", t => t.AccountId)
                .Index(t => t.AccountId)
                .Index(t => t.GroupId);
            
            CreateTable(
                "dbo.Groups",
                c => new
                    {
                        GroupId = c.Int(nullable: false, identity: true),
                        GroupName = c.String(nullable: false),
                        SpecialityId = c.Int(nullable: false),
                        Approve = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.GroupId)
                .ForeignKey("dbo.Specialities", t => t.SpecialityId)
                .Index(t => t.SpecialityId);
            
            CreateTable(
                "dbo.Lessons",
                c => new
                    {
                        LessonId = c.Int(nullable: false, identity: true),
                        IsDeleted = c.Boolean(nullable: false),
                        DayOfWeek = c.Int(nullable: false),
                        TypeOfWeek = c.Int(nullable: false),
                        LessonType = c.Int(nullable: false),
                        DateTimeStart = c.DateTime(nullable: false),
                        DateTimeEnd = c.DateTime(nullable: false),
                        SubGroup = c.Int(nullable: false),
                        TeacherId = c.Int(nullable: false),
                        SubjectId = c.Int(nullable: false),
                        ClassRoomId = c.Int(nullable: false),
                        UniversityId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.LessonId)
                .ForeignKey("dbo.ClassRooms", t => t.ClassRoomId)
                .ForeignKey("dbo.Universities", t => t.UniversityId)
                .ForeignKey("dbo.Subjects", t => t.SubjectId)
                .ForeignKey("dbo.Teachers", t => t.TeacherId)
                .Index(t => t.TeacherId)
                .Index(t => t.SubjectId)
                .Index(t => t.ClassRoomId)
                .Index(t => t.UniversityId);
            
            CreateTable(
                "dbo.ClassRooms",
                c => new
                    {
                        ClassRoomId = c.Int(nullable: false, identity: true),
                        ClassRoomName = c.String(nullable: false),
                        UniversityId = c.Int(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ClassRoomId)
                .ForeignKey("dbo.Universities", t => t.UniversityId)
                .Index(t => t.UniversityId);
            
            CreateTable(
                "dbo.Universities",
                c => new
                    {
                        UniversityId = c.Int(nullable: false, identity: true),
                        UniversityName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CityId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.UniversityId)
                .ForeignKey("dbo.Cities", t => t.CityId)
                .Index(t => t.CityId);
            
            CreateTable(
                "dbo.Cities",
                c => new
                    {
                        CityId = c.Int(nullable: false, identity: true),
                        CityName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        Longitude = c.String(nullable: false),
                        Latitude = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.CityId);
            
            CreateTable(
                "dbo.Schedules",
                c => new
                    {
                        ScheduleId = c.Int(nullable: false, identity: true),
                        ScheduleNumber = c.Int(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        StartLesson = c.DateTime(nullable: false),
                        EndLesson = c.DateTime(nullable: false),
                        UniversityId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ScheduleId)
                .ForeignKey("dbo.Universities", t => t.UniversityId)
                .Index(t => t.UniversityId);
            
            CreateTable(
                "dbo.Subjects",
                c => new
                    {
                        SubjectId = c.Int(nullable: false, identity: true),
                        SubjectName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        UniversityId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SubjectId)
                .ForeignKey("dbo.Universities", t => t.UniversityId)
                .Index(t => t.UniversityId);
            
            CreateTable(
                "dbo.Terms",
                c => new
                    {
                        TermId = c.Int(nullable: false, identity: true),
                        IsDeleted = c.Boolean(nullable: false),
                        UniversityId = c.Int(nullable: false),
                        Start = c.DateTime(nullable: false),
                        End = c.DateTime(nullable: false),
                        StartTypeWeek = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.TermId)
                .ForeignKey("dbo.Universities", t => t.UniversityId)
                .Index(t => t.UniversityId);
            
            CreateTable(
                "dbo.Teachers",
                c => new
                    {
                        TeacherId = c.Int(nullable: false, identity: true),
                        TeacherName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CathedraId = c.Int(nullable: false),
                        AccountId = c.String(maxLength: 128),
                        Approve = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.TeacherId)
                .ForeignKey("dbo.AspNetUsers", t => t.AccountId)
                .ForeignKey("dbo.Cathedras", t => t.CathedraId)
                .Index(t => t.CathedraId)
                .Index(t => t.AccountId);
            
            CreateTable(
                "dbo.Specialities",
                c => new
                    {
                        SpecialityId = c.Int(nullable: false, identity: true),
                        SpecialityName = c.String(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        FacultyId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SpecialityId)
                .ForeignKey("dbo.Faculties", t => t.FacultyId)
                .Index(t => t.FacultyId);
            
            CreateTable(
                "dbo.AspNetRoles",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(),
                        IsDeleted = c.Boolean(),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Name, unique: true, name: "RoleNameIndex");
            
            CreateTable(
                "dbo.ScheduleLessons",
                c => new
                    {
                        Schedule_ScheduleId = c.Int(nullable: false),
                        Lesson_LessonId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Schedule_ScheduleId, t.Lesson_LessonId })
                .ForeignKey("dbo.Schedules", t => t.Schedule_ScheduleId, cascadeDelete: true)
                .ForeignKey("dbo.Lessons", t => t.Lesson_LessonId, cascadeDelete: true)
                .Index(t => t.Schedule_ScheduleId)
                .Index(t => t.Lesson_LessonId);
            
            CreateTable(
                "dbo.GroupLessons",
                c => new
                    {
                        Group_GroupId = c.Int(nullable: false),
                        Lesson_LessonId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Group_GroupId, t.Lesson_LessonId })
                .ForeignKey("dbo.Groups", t => t.Group_GroupId, cascadeDelete: true)
                .ForeignKey("dbo.Lessons", t => t.Lesson_LessonId, cascadeDelete: true)
                .Index(t => t.Group_GroupId)
                .Index(t => t.Lesson_LessonId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.Teachers", "CathedraId", "dbo.Cathedras");
            DropForeignKey("dbo.Specialities", "FacultyId", "dbo.Faculties");
            DropForeignKey("dbo.Cathedras", "FacultyId", "dbo.Faculties");
            DropForeignKey("dbo.Faculties", "AccountId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUsers", "TeacherId", "dbo.Teachers");
            DropForeignKey("dbo.Students", "AccountId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Students", "GroupId", "dbo.Groups");
            DropForeignKey("dbo.Groups", "SpecialityId", "dbo.Specialities");
            DropForeignKey("dbo.GroupLessons", "Lesson_LessonId", "dbo.Lessons");
            DropForeignKey("dbo.GroupLessons", "Group_GroupId", "dbo.Groups");
            DropForeignKey("dbo.Lessons", "TeacherId", "dbo.Teachers");
            DropForeignKey("dbo.Teachers", "AccountId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Terms", "UniversityId", "dbo.Universities");
            DropForeignKey("dbo.Subjects", "UniversityId", "dbo.Universities");
            DropForeignKey("dbo.Lessons", "SubjectId", "dbo.Subjects");
            DropForeignKey("dbo.Schedules", "UniversityId", "dbo.Universities");
            DropForeignKey("dbo.ScheduleLessons", "Lesson_LessonId", "dbo.Lessons");
            DropForeignKey("dbo.ScheduleLessons", "Schedule_ScheduleId", "dbo.Schedules");
            DropForeignKey("dbo.Lessons", "UniversityId", "dbo.Universities");
            DropForeignKey("dbo.Faculties", "UniversityId", "dbo.Universities");
            DropForeignKey("dbo.ClassRooms", "UniversityId", "dbo.Universities");
            DropForeignKey("dbo.Universities", "CityId", "dbo.Cities");
            DropForeignKey("dbo.Lessons", "ClassRoomId", "dbo.ClassRooms");
            DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.LogItems", "AccountId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUsers", "FacultyId", "dbo.Faculties");
            DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.GroupLessons", new[] { "Lesson_LessonId" });
            DropIndex("dbo.GroupLessons", new[] { "Group_GroupId" });
            DropIndex("dbo.ScheduleLessons", new[] { "Lesson_LessonId" });
            DropIndex("dbo.ScheduleLessons", new[] { "Schedule_ScheduleId" });
            DropIndex("dbo.AspNetRoles", "RoleNameIndex");
            DropIndex("dbo.Specialities", new[] { "FacultyId" });
            DropIndex("dbo.Teachers", new[] { "AccountId" });
            DropIndex("dbo.Teachers", new[] { "CathedraId" });
            DropIndex("dbo.Terms", new[] { "UniversityId" });
            DropIndex("dbo.Subjects", new[] { "UniversityId" });
            DropIndex("dbo.Schedules", new[] { "UniversityId" });
            DropIndex("dbo.Universities", new[] { "CityId" });
            DropIndex("dbo.ClassRooms", new[] { "UniversityId" });
            DropIndex("dbo.Lessons", new[] { "UniversityId" });
            DropIndex("dbo.Lessons", new[] { "ClassRoomId" });
            DropIndex("dbo.Lessons", new[] { "SubjectId" });
            DropIndex("dbo.Lessons", new[] { "TeacherId" });
            DropIndex("dbo.Groups", new[] { "SpecialityId" });
            DropIndex("dbo.Students", new[] { "GroupId" });
            DropIndex("dbo.Students", new[] { "AccountId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
            DropIndex("dbo.LogItems", new[] { "AccountId" });
            DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
            DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
            DropIndex("dbo.AspNetUsers", "UserNameIndex");
            DropIndex("dbo.AspNetUsers", new[] { "FacultyId" });
            DropIndex("dbo.AspNetUsers", new[] { "TeacherId" });
            DropIndex("dbo.Faculties", new[] { "AccountId" });
            DropIndex("dbo.Faculties", new[] { "UniversityId" });
            DropIndex("dbo.Cathedras", new[] { "FacultyId" });
            DropTable("dbo.GroupLessons");
            DropTable("dbo.ScheduleLessons");
            DropTable("dbo.AspNetRoles");
            DropTable("dbo.Specialities");
            DropTable("dbo.Teachers");
            DropTable("dbo.Terms");
            DropTable("dbo.Subjects");
            DropTable("dbo.Schedules");
            DropTable("dbo.Cities");
            DropTable("dbo.Universities");
            DropTable("dbo.ClassRooms");
            DropTable("dbo.Lessons");
            DropTable("dbo.Groups");
            DropTable("dbo.Students");
            DropTable("dbo.AspNetUserRoles");
            DropTable("dbo.LogItems");
            DropTable("dbo.AspNetUserLogins");
            DropTable("dbo.AspNetUserClaims");
            DropTable("dbo.AspNetUsers");
            DropTable("dbo.Faculties");
            DropTable("dbo.Cathedras");
        }
    }
}
