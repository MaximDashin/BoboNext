﻿using System.Data.Entity;

namespace BoboNext.Data
{
    public class RoleInitializer : CreateDatabaseIfNotExists<DatabaseContext>
    {

    }
}
