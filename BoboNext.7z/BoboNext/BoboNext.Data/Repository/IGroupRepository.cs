﻿using System.Collections.Generic;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface IGroupRepository
    {
        IEnumerable<Group> Groups { get; }

        void AddGroup(Group group);
        void EditGroup(Group group);
        void DeleteGroup(int groupId);
        Group GetGroupById(int groupId);

    }
}