﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface ICityRepository
    {
        IEnumerable<City> Cities { get; }

        void AddCity(City city);
        void EditCity(City city);
        void DeleteCity(int cityId);
        City GetCityById(int cityId);

    }
}
