﻿using System.Collections.Generic;
using System.Linq;
using BoboNext.Core;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface ITeacherRepository
    {
        IQueryable<Teacher> Teachers { get; }

        void AddTeacher(Teacher teacher);
        void EditTeacher(Teacher teacher);
        void DeleteTeacher(int teacherId);
        Teacher GetTeacherById(int teacherId);
        IEnumerable<Teacher> Search(string teacherName, string university);

    }
}