﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class UniversityRepository : IUniversityRepository
    {
        private readonly IDatabaseContext _context;

        public UniversityRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<University> Universities => _context.Universities.Where(u => !u.IsDeleted);

        public void AddUniversity(University university)
        {
            if (university == null)
                throw new ArgumentNullException(nameof(university));

            _context.Universities.Add(university);

            _context.SaveChanges();
        }

        public void EditUniversity(University university)
        {
            if (university == null)
                throw new ArgumentNullException(nameof(university));

            var dbItem = Universities.First(e => e.UniversityId == university.UniversityId);

            university.CopyWithChecking(dbItem,
                e => e.UniversityName,
                e => e.CityId);

            //_context.Entry(university).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteUniversity(int universityId)
        {
            var dbUniversity = _context.Universities.FirstOrDefault(c => c.UniversityId == universityId);
            if (dbUniversity != null)
            {
                dbUniversity.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public University GetUniversityById(int universityId)
        {
            var dbUniversity = _context.Universities.FirstOrDefault(c => c.UniversityId == universityId);
            if (dbUniversity == null)
                throw new ArgumentNullException(nameof(dbUniversity));

            return dbUniversity;
        }

    }
}
