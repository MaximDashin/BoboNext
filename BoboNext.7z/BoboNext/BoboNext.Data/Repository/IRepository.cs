﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace BoboNext.Data.Repository
{
    public interface IRepository<T>
        where T : class
    {

        IDatabaseContext Context { get; }

        void Update(T entity);

        void Update(IEnumerable<T> entities);

        void Add(T entity);

        void Add(IEnumerable<T> entities);

        void Remove(T entity);

        void Remove(IEnumerable<T> entities);

        EntityState State(T entity);

        void AddOrUpdate(T item);

        void AddOrUpdate(IEnumerable<T> items);

        IQueryable<T> Table { get; }

        IQueryable<T> TableNoTracking { get; }

    }
}
