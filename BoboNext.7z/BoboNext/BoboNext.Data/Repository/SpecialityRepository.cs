﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class SpecialityRepository : ISpecialityRepository
    {
        private readonly IDatabaseContext _context;

        public SpecialityRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Speciality> Specialities => _context.Specialities.Where(s => !s.IsDeleted);

        public void AddSpeciality(Speciality speciality)
        {
            if (speciality == null)
                throw new ArgumentNullException(nameof(speciality));

            _context.Specialities.Add(speciality);

            _context.SaveChanges();
        }

        public void EditSpeciality(Speciality speciality)
        {
            if (speciality == null)
                throw new ArgumentNullException(nameof(speciality));

            var dbItem = Specialities.First(e => e.SpecialityId == speciality.SpecialityId);

            speciality.CopyWithChecking(dbItem,
                e => e.SpecialityName,
                e => e.FacultyId);

            //_context.Entry(speciality).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteSpeciality(int specialityId)
        {
            var dbSpeciality = _context.Specialities.FirstOrDefault(c => c.SpecialityId == specialityId);
            if (dbSpeciality != null)
            {
                dbSpeciality.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public Speciality GetSpecialityById(int specialityId)
        {
            var dbSpeciality = _context.Specialities.FirstOrDefault(c => c.SpecialityId == specialityId);
            if (dbSpeciality == null)
                throw new ArgumentNullException(nameof(dbSpeciality));

            return dbSpeciality;
        }

    }
}
