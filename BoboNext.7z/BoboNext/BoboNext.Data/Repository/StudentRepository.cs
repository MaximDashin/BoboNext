﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly IDatabaseContext _context;

        public StudentRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Student> Students => _context.Students;

        public void AddStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student));

            _context.Students.Add(student);

            _context.SaveChanges();
        }

        public void EditStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student));

            var dbItem = Students.First(e => e.AccountId == student.AccountId);

            student.CopyWithChecking(dbItem,
                e => e.GroupId);

            //_context.Entry(student).State = EntityState.Modified;

            _context.SaveChanges();
        }

        //public void DeleteStudent(int studentId)
        //{
        //    var dbStudent = _context.Students.FirstOrDefault(c => c.AccountId == studentId);
        //    if (dbStudent != null)
        //    {
        //        dbStudent.IsDeleted = true;
        //    }
        //    _context.SaveChanges();
        //}

        //public Student GetStudentById(int studentId)
        //{
        //    var dbStudent = _context.Students.FirstOrDefault(c => c.StudentId == studentId);

        //    return dbStudent;
        //}
    }
}