﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace BoboNext.Data.Repository
{
    public abstract class Repository<T> : IRepository<T>
        where T : class
    {
        public Repository(IDatabaseContext context)
        {
            Context = context;
        }

        public IDatabaseContext Context { get; }


        public virtual void Update(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            var dbEntityEntry = Context.Entry(entity);
            if (dbEntityEntry.State == EntityState.Detached)
                throw new InvalidOperationException("Update detached entity");
            dbEntityEntry.State = EntityState.Modified;
            SaveChanges();
        }

        public virtual void Update(IEnumerable<T> entities)
        {
            if (entities == null) throw new ArgumentNullException(nameof(entities));

            foreach (var item in entities)
            {
                var dbEntityEntry = Context.Entry(item);
                if (dbEntityEntry.State == EntityState.Detached)
                    throw new InvalidOperationException("Update detached entity");
                dbEntityEntry.State = EntityState.Modified;
            }
            SaveChanges();
        }

        public virtual void Add(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            Context.Set<T>().Add(entity);
            SaveChanges();
        }

        public virtual void Add(IEnumerable<T> entities)
        {
            if (entities == null) throw new ArgumentNullException(nameof(entities));
            foreach (var entity in entities)
            {
                if (entity == null) throw new ArgumentNullException(nameof(entities));
                Context.Set<T>().Add(entity);
            }
            SaveChanges();
        }

        public virtual void Remove(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            Context.Set<T>().Remove(entity);
            SaveChanges();
        }

        public virtual void Remove(IEnumerable<T> entities)
        {
            if (entities == null) throw new ArgumentNullException(nameof(entities));
            foreach (var entity in entities)
            {
                if (entity == null)
                    throw new ArgumentNullException(nameof(entities));
                Context.Set<T>().Remove(entity);
            }
            SaveChanges();
        }

        public virtual EntityState State(T entity)
        {
            var entityState = Context.Entry(entity).State;
            return (EntityState)entityState;
        }

        public virtual void AddOrUpdate(T item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            if (State(item) == EntityState.Detached)
                Add(item);
            else
                Update(item);
        }

        public virtual void AddOrUpdate(IEnumerable<T> items)
        {
            if (items == null)
                throw new ArgumentNullException(nameof(items));
            foreach (var address in items)
                AddOrUpdate(address);
        }

        protected void SaveChanges()
        {
            Context.SaveChanges();
        }

        public IQueryable<T> Table => Context.Set<T>();

        public IQueryable<T> TableNoTracking => Context.Set<T>().AsNoTracking();
    }
}