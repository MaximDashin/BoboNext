﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class CityRepository : ICityRepository
    {
        private readonly IDatabaseContext _context;

        public CityRepository(IDatabaseContext context)
        {
            _context = context;
        }


        public IEnumerable<City> Cities => _context.Cities.Where(c=>!c.IsDeleted);

        public void EditCity(City city)
        {
            if (city == null)
                throw new ArgumentNullException(nameof(city));

            var dbCity = Cities.First(e => e.CityId == city.CityId);

            city.CopyWithChecking(dbCity,
                e => e.CityName,
                e => e.Longitude,
                e => e.Latitude);

            //_context.Entry(city).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void AddCity(City city)
        {
            if (city == null)
                throw new ArgumentNullException(nameof(city));

            _context.Cities.Add(city);
            
            _context.SaveChanges();
        }


        public void DeleteCity(int cityId)
        {
            var dbCity = _context.Cities.FirstOrDefault(c => c.CityId == cityId);
            if (dbCity != null)
            {
                dbCity.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public City GetCityById(int cityId)
        {
            var dbCity = Cities.FirstOrDefault(c => c.CityId == cityId);
            if (dbCity == null)
                throw new ArgumentNullException(nameof(dbCity));

            return dbCity;
        }


    }
}
