﻿using System;
using BoboNext.Core.Domain.System;

namespace BoboNext.Data.Repository
{
    public class LogsRepository : ILogsRepository
    {
        private readonly IDatabaseContext _context;

        public LogsRepository(IDatabaseContext context1)
        {
            _context = context1;
        }

        public void AddLog(LogItem logItem)
        {
            if (logItem == null)
                throw new ArgumentNullException(nameof(logItem));

            _context.LogItems.Add(logItem);
            _context.SaveChanges();

        }
    }
}