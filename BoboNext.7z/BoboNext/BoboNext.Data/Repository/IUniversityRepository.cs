﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoboNext.Core;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface IUniversityRepository
    {
        IEnumerable<University> Universities { get; }

        void AddUniversity(University university);
        void EditUniversity(University university);
        void DeleteUniversity(int universityId);
        University GetUniversityById(int universityId);


    }
}
