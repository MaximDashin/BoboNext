﻿using System.Collections.Generic;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public interface ILessonRepository
    {
        IEnumerable<Lesson> Lessons { get; }

        int AddLesson(Lesson lesson);
        void EditLesson(Lesson lesson);
        void DeleteLesson(int lessonId);
        Lesson GetLessonById(int lessonId);
        IEnumerable<Group> GetGroupsByIds(IEnumerable<int> idGroups);
        IEnumerable<Schedule> GetSchedulesByIds(IEnumerable<int> idSchedules);
    }
}