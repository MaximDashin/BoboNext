﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.Authorize;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class AccountRepository : IAccountRepository
    {
        private readonly IDatabaseContext _context;

        public AccountRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Account> Accounts => _context.Set<Account>().Where(a => !a.IsDeleted);

        public void AddAccount(Account account)
        {
            if (account == null)
                throw new ArgumentNullException(nameof(account));
            _context.Set<Account>().Add(account);

            _context.SaveChanges();
        }

        public void EditAccount(Account account)
        {
            if (account == null)
                throw new ArgumentNullException(nameof(account));

            var dbItem = Accounts.First(e => e.Id == account.Id);

            account.CopyWithChecking(dbItem,
                e => e.Student,
                e => e.TeacherId,
                e => e.Teacher,
                e => e.FacultyId,
                e => e.Faculty,
                e => e.Approve);

            //_context.Entry(account).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteAccount(string accountId)
        {
            var dbAccount = _context.Set<Account>().FirstOrDefault(c => c.Id == accountId);
            if (dbAccount != null)
            {
                dbAccount.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public Account GetAccountById(string accountId)
        {
            var dbAccount = _context.Set<Account>().FirstOrDefault(c => c.Id == accountId);
            if (dbAccount == null)
            {
                throw new ArgumentNullException(nameof(dbAccount));
            }

            return dbAccount;
        }

        public Account GetAccountByName(string accountName)
        {
            var dbAccount = _context.Set<Account>().FirstOrDefault(c => c.Email == accountName);
            if (dbAccount == null)
            {
                throw new ArgumentNullException(nameof(dbAccount));
            }

            return dbAccount;
        }

        public Account GetAccountFromAccountViewModel(AccountViewModel model)
        {
            var account = new Account { UserName = model.Email, Email = model.Email };
            if (model.TeacherId != 0)
            {
                account.TeacherId = model.TeacherId;
            }
            else if (model.FacultyId != 0)
            {
                account.FacultyId = model.FacultyId;
            }

            return account;
        }

        public Account GetAccountFromRegistrationViewModel(RegistrationViewModel model)
        {
            var account = new Account { UserName = model.Email, Email = model.Email };
            if (model.TeacherId != 0)
            {
                account.TeacherId = model.TeacherId;
            }

            return account;
        }

        public AccountViewModel GetAccountViewModelFromAccount(string accountId)
        {
            var account = GetAccountById(accountId);

            var model = new AccountViewModel
            {
                AccountId = account.Id,
                Email = account.UserName,
                GroupId = account.Student?.GroupId ?? 0,
                TeacherId = account.TeacherId.HasValue ? account.Teacher.TeacherId : 0,
                FacultyId = account.FacultyId.HasValue ? account.Faculty.FacultyId : 0
            };

            if (model.GroupId != 0)
            {
                model.TypeRegister = 4;
                model.UniversityId = account.Student.Group.Speciality.Faculty.UniversityId;
            }
            else if (model.TeacherId != 0)
            {
                model.TypeRegister = 3;
                model.UniversityId = account.Teacher.Cathedra.Faculty.UniversityId;
            }
            else if (model.FacultyId != 0)
            {
                model.TypeRegister = 2;
                model.UniversityId = account.Faculty.UniversityId;
            }
            else
                model.TypeRegister = 1;

            return model;
        }
    }
}