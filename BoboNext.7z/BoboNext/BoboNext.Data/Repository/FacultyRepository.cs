﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class FacultyRepository : IFacultyRepository
    {
        private readonly IDatabaseContext _context;

        public FacultyRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Faculty> Faculties => _context.Faculties.Where(c => !c.IsDeleted);

        public void AddFaculty(Faculty faculty)
        {
            if (faculty == null)
                throw new ArgumentNullException(nameof(faculty));

            _context.Faculties.Add(faculty);

            _context.SaveChanges();
        }

        public void EditFaculty(Faculty faculty)
        {
            if (faculty == null)
                throw new ArgumentNullException(nameof(faculty));

            var dbItem = Faculties.First(e => e.FacultyId == faculty.FacultyId);

            faculty.CopyWithChecking(dbItem,
                e => e.FacultyName,
                e => e.UniversityId);

            //_context.Entry(faculty).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteFaculty(int facultyId)
        {
            var dbFaculty = _context.Faculties.FirstOrDefault(c => c.FacultyId == facultyId);
            if (dbFaculty != null)
            {
                dbFaculty.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public Faculty GetFacultyById(int facultyId)
        {
            var dbFaculty = Faculties.FirstOrDefault(c => c.FacultyId == facultyId);
            if (dbFaculty == null)
                throw new ArgumentNullException(nameof(dbFaculty));

            return dbFaculty;
        }

    }
}
