﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public interface ITermRepository
    {
        IEnumerable<Term> Terms { get; }

        void AddTerm(Term term);
        void EditTerm(Term term);
        void DeleteTerm(int termId);
        Term GetTermById(int termId);
        IEnumerable<Term> Search(string university);
    }
}