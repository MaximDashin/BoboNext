﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.ViewModels;
using static System.String;

namespace BoboNext.Data.Repository
{
    public class SubjectRepository : ISubjectRepository
    {
        private readonly IDatabaseContext _context;

        public SubjectRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Subject> Subjects => _context.Subjects.Where(s => !s.IsDeleted);

        public void AddSubject(Subject subject)
        {
            if (subject == null)
                throw new ArgumentNullException(nameof(subject));

            _context.Subjects.Add(subject);

            _context.SaveChanges();
        }

        public void EditSubject(Subject subject)
        {
            if (subject == null)
                throw new ArgumentNullException(nameof(subject));

            var dbItem = Subjects.First(e => e.SubjectId == subject.SubjectId);

            subject.CopyWithChecking(dbItem,
                e => e.SubjectName,
                e => e.UniversityId);

            //_context.Entry(subject).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteSubject(int subjectId)
        {
            var dbSubject = _context.Subjects.FirstOrDefault(c => c.SubjectId == subjectId);
            if (dbSubject != null)
                dbSubject.IsDeleted = true;

            _context.SaveChanges();
        }

        public Subject GetSubjectById(int subjectId)
        {
            var dbSubject = _context.Subjects.FirstOrDefault(c => c.SubjectId == subjectId);
            if (dbSubject == null)
                throw new ArgumentNullException(nameof(dbSubject));

            return dbSubject;
        }

        public IEnumerable<Subject> Search(string subjectName)
        {
            if (!IsNullOrEmpty(subjectName))
                return Subjects.Where(x => x.SubjectName
                    .Contains(subjectName) && !x.IsDeleted)
                    .OrderBy(x => x.SubjectName)
                    .ToList();
            return Subjects.Where(x => !x.IsDeleted)
                .OrderBy(x => x.SubjectName)
                .ToList();
        }

    }
}