﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class GroupRepository : IGroupRepository
    {
        private readonly IDatabaseContext _context;

        public GroupRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Group> Groups => _context.Groups.Where(g => !g.IsDeleted);

        public void AddGroup(Group group)
        {
            if (group == null)
                throw new ArgumentNullException(nameof(group));

            _context.Groups.Add(group);

            _context.SaveChanges();
        }

        public void EditGroup(Group group)
        {
            if (group == null)
                throw new ArgumentNullException(nameof(group));

            var dbGroup = Groups.First(e => e.GroupId == group.GroupId);

            group.CopyWithChecking(dbGroup,
                e => e.GroupName,
                e => e.Approve,
                e => e.SpecialityId);

            //_context.Entry(group).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteGroup(int groupId)
        {
            var dbGroup = _context.Groups.FirstOrDefault(c => c.GroupId == groupId);
            if (dbGroup != null)
            {
                dbGroup.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public Group GetGroupById(int groupId)
        {
            var dbGroup = Groups.FirstOrDefault(c => c.GroupId == groupId);
            if (dbGroup == null)
                throw new ArgumentNullException(nameof(dbGroup));

            return dbGroup;
        }

    }
}