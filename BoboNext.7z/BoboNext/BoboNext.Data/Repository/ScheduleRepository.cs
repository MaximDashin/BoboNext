﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public class ScheduleRepository : IScheduleRepository
    {
        private readonly IDatabaseContext _context;

        public ScheduleRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Schedule> Schedules => _context.Schedules.Where(c => !c.IsDeleted);

        public void AddSchedule(Schedule schedule)
        {
            if (schedule == null)
                throw new ArgumentNullException(nameof(schedule));

            _context.Schedules.Add(schedule);

            _context.SaveChanges();
        }

        public void EditSchedule(Schedule schedule)
        {
            if (schedule == null)
                throw new ArgumentNullException(nameof(schedule));

            var dbItem = Schedules.First(e => e.ScheduleId == schedule.ScheduleId);

            schedule.CopyWithChecking(dbItem,
                e => e.ScheduleNumber,
                e => e.StartLesson,
                e => e.EndLesson,
                e => e.UniversityId);

            //_context.Entry(schedule).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteSchedule(int scheduleId)
        {
            var dbSchedule = _context.Schedules.FirstOrDefault(c => c.ScheduleId == scheduleId);
            if (dbSchedule != null)
                dbSchedule.IsDeleted = true;

            _context.SaveChanges();
        }

        public Schedule GetScheduleById(int scheduleId)
        {
            var dbSchedule = _context.Schedules.FirstOrDefault(c => c.ScheduleId == scheduleId);
            if (dbSchedule == null)
                throw new ArgumentNullException(nameof(dbSchedule));

            return dbSchedule;
        }
    }
}