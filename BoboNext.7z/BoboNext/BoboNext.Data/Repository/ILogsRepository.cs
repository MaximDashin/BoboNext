﻿using BoboNext.Core.Domain.System;

namespace BoboNext.Data.Repository
{
    public interface ILogsRepository
    {
        void AddLog(LogItem logItem);
    }
}