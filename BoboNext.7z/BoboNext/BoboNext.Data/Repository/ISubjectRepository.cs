﻿using System.Collections.Generic;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface ISubjectRepository
    {
        IEnumerable<Subject> Subjects { get; }

        void AddSubject(Subject subject);
        void EditSubject(Subject subject);
        void DeleteSubject(int subjectId);
        Subject GetSubjectById(int subjectId);
        IEnumerable<Subject> Search(string subjectName);

    }
}