﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public interface IStudentRepository
    {
        IEnumerable<Student> Students { get; }

        void AddStudent(Student student);
        void EditStudent(Student student);
        //void DeleteStudent(int studentId);
        //Student GetStudentById(int studentId);
    }
}