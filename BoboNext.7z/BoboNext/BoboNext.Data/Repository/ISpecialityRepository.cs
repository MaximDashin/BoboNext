﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface ISpecialityRepository
    {
        IEnumerable<Speciality> Specialities { get; }

        void AddSpeciality(Speciality speciality);
        void EditSpeciality(Speciality speciality);
        void DeleteSpeciality(int specialityId);
        Speciality GetSpecialityById(int specialityId);
    }
}