﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;
using static System.String;

namespace BoboNext.Data.Repository
{
    public class TermRepository : ITermRepository
    {
        private readonly IDatabaseContext _context;

        public TermRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Term> Terms => _context.Terms.Where(t => !t.IsDeleted);

        public void AddTerm(Term term)
        {
            if (term == null)
                throw new ArgumentNullException(nameof(term));

            _context.Terms.Add(term);

            _context.SaveChanges();
        }

        public void EditTerm(Term term)
        {
            if (term == null)
                throw new ArgumentNullException(nameof(term));

            var dbItem = Terms.First(e => e.TermId == term.TermId);

            term.CopyWithChecking(dbItem,
                e => e.UniversityId,
                e => e.StartTypeWeek,
                e => e.Start,
                e => e.End);

            //_context.Entry(term).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteTerm(int termId)
        {
            var dbTerm = _context.Terms.FirstOrDefault(c => c.TermId == termId);
            if (dbTerm != null)
                dbTerm.IsDeleted = true;

            _context.SaveChanges();
        }

        public Term GetTermById(int termId)
        {
            var dbTerm = _context.Terms.FirstOrDefault(c => c.TermId == termId);
            if (dbTerm == null)
                throw new ArgumentNullException(nameof(dbTerm));

            return dbTerm;
        }

        public IEnumerable<Term> Search(string university)
        {
            if (IsNullOrEmpty(university))
                university = "";

            return from term in Terms
                where term.University.UniversityName.Contains(university)
                orderby term.University.UniversityName
                orderby term.Start descending
                select term;
        }
    }
}