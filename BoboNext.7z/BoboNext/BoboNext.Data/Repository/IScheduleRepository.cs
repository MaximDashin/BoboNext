﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public interface IScheduleRepository
    {
        IEnumerable<Schedule> Schedules { get; }

        void AddSchedule(Schedule schedule);
        void EditSchedule(Schedule schedule);
        void DeleteSchedule(int scheduleId);
        Schedule GetScheduleById(int scheduleId);
    }
}