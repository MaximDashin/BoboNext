﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public class ClassRoomRepository : IClassRoomRepository
    {
        private readonly IDatabaseContext _context;

        public ClassRoomRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<ClassRoom> ClassRooms => _context.ClassRooms.Where(c => !c.IsDeleted);

        public void AddClassRoom(ClassRoom classRoom)
        {
            if (classRoom == null)
                throw new ArgumentNullException(nameof(classRoom));

            _context.ClassRooms.Add(classRoom);

            _context.SaveChanges();
        }

        public void EditClassRoom(ClassRoom classRoom)
        {
            if (classRoom == null)
                throw new ArgumentNullException(nameof(classRoom));

            var dbRoom = ClassRooms.First(e => e.ClassRoomId == classRoom.ClassRoomId);

            classRoom.CopyWithChecking(dbRoom,
                e => e.ClassRoomName,
                e => e.UniversityId);

            //_context.Entry(classRoom).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteClassRoom(int classRoomId)
        {
            var dbClassRoom = _context.ClassRooms.FirstOrDefault(c => c.ClassRoomId == classRoomId);
            if (dbClassRoom != null)
                dbClassRoom.IsDeleted = true;

            _context.SaveChanges();
        }

        public ClassRoom GetClassRoomById(int classRoomId)
        {
            var dbClassRoom = _context.ClassRooms.FirstOrDefault(c => c.ClassRoomId == classRoomId);
            if (dbClassRoom == null)
                throw new ArgumentNullException(nameof(dbClassRoom));

            return dbClassRoom;
        }

        public IEnumerable<ClassRoom> Search(string classRoom, string university)
        {
            if (string.IsNullOrEmpty(classRoom))
                classRoom = "";
            if (string.IsNullOrEmpty(university))
                university = "";

            classRoom = classRoom.Trim();
            university = university.Trim();
            return ClassRooms.Where(x => x.ClassRoomName.Contains(classRoom)
                                         && x.University.UniversityName.Contains(university)
                                         && !x.IsDeleted)
                .OrderBy(room => room.ClassRoomName);
        }
    }
}