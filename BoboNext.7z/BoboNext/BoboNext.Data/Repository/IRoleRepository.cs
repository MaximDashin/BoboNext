﻿using System.Collections.Generic;
using BoboNext.Core.Domain.Authorize;
using Microsoft.AspNet.Identity.EntityFramework;

namespace BoboNext.Data.Repository
{
    public interface IRoleRepository
    {
        IEnumerable<Role> Roles { get; }

        void AddRole(Role role);
        void EditRole(Role role);
        void DeleteRole(string roleId);
        IdentityRole GetRoleByValue(string roleName);
    }
}