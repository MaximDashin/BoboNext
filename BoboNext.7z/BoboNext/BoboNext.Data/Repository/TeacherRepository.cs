﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;
using static System.String;

namespace BoboNext.Data.Repository
{
    public class TeacherRepository : ITeacherRepository
    {
        private readonly IDatabaseContext _context;

        public TeacherRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IQueryable<Teacher> Teachers => _context.Teachers.Where(g => !g.IsDeleted);

        public void AddTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher));

            _context.Teachers.Add(teacher);

            _context.SaveChanges();
        }

        public void EditTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher));

            var dbItem = Teachers.First(e => e.TeacherId == teacher.TeacherId);

            teacher.CopyWithChecking(dbItem,
                e => e.TeacherName,
                e => e.Approve,
                e => e.CathedraId);

            //_context.Entry(teacher).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteTeacher(int teacherId)
        {
            var dbTeacher = _context.Teachers.FirstOrDefault(c => c.TeacherId == teacherId);
            if (dbTeacher != null)
                dbTeacher.IsDeleted = true;

            _context.SaveChanges();
        }

        public Teacher GetTeacherById(int teacherId)
        {
            var dbTeacher = _context.Teachers.FirstOrDefault(c => c.TeacherId == teacherId);
            if (dbTeacher == null)
                throw new ArgumentNullException(nameof(dbTeacher));

            return dbTeacher;
        }

        public IEnumerable<Teacher> Search(string teacherName, string university)
        {
            if (IsNullOrEmpty(teacherName))
                teacherName = "";
            if (IsNullOrEmpty(university))
                university = "";

            teacherName = teacherName.Trim();
            university = university.Trim();
            return Teachers.Include(t => t.Cathedra)
                .Where(x => x.TeacherName.Contains(teacherName) 
                && x.Cathedra.Faculty.University.UniversityName.Contains(university) 
                && !x.IsDeleted).OrderBy(x => x.TeacherName);
        }

    }
}