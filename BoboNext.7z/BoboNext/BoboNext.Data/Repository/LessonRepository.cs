﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public class LessonRepository : ILessonRepository
    {
        private readonly IDatabaseContext _context;

        public LessonRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Lesson> Lessons => _context.Lessons.Where(g => !g.IsDeleted);

        public int AddLesson(Lesson lesson)
        {
            if (lesson == null)
                throw new ArgumentNullException(nameof(lesson));

            _context.Lessons.Add(lesson);

            _context.SaveChanges();
            return lesson.LessonId;
        }

        public void EditLesson(Lesson lesson)
        {
            if (lesson == null)
                throw new ArgumentNullException(nameof(lesson));

            var dbLesson = GetLessonById(lesson.LessonId);

            lesson.CopyWithChecking(dbLesson,
                e => e.DayOfWeek,
                e => e.TypeOfWeek,
                e => e.LessonType,
                e => e.DateTimeStart,
                e => e.DateTimeEnd,
                e => e.SubGroup,
                e => e.TeacherId,
                e => e.SubjectId,
                e => e.ClassRoomId,
                e => e.UniversityId);

            foreach (var @group in lesson.Groups.Where(@group => !dbLesson.Groups.Contains(@group)))
            {
                dbLesson.Groups.Add(@group);
            }
            foreach (var @group in dbLesson.Groups.ToList().Where(@group => !lesson.Groups.Contains(@group)))
            {
                dbLesson.Groups.Remove(@group);
            }


            foreach (var schedule in lesson.Schedules.Where(schedule => !dbLesson.Schedules.Contains(schedule)))
            {
                dbLesson.Schedules.Add(schedule);
            }
            foreach (var schedule in dbLesson.Schedules.ToList().Where(schedule => !lesson.Schedules.Contains(schedule)))
            {
                dbLesson.Schedules.Remove(schedule);
            }

            _context.SaveChanges();
        }

        public IEnumerable<Group> GetGroupsByIds(IEnumerable<int> idGroups)
        {
            
            return idGroups.Select(@group => _context.Set<Group>().First(e=>e.GroupId == @group));
        }

        public IEnumerable<Schedule> GetSchedulesByIds(IEnumerable<int> idSchedules)
        {
            return idSchedules.Select(scheduleId => _context.Set<Schedule>().First(e => e.ScheduleId == scheduleId));
        }


        public void DeleteLesson(int lessonId)
        {
            var dbLesson = _context.Lessons.FirstOrDefault(c => c.LessonId == lessonId);
            if (dbLesson != null)
                dbLesson.IsDeleted = true;

            _context.SaveChanges();
        }

        public Lesson GetLessonById(int lessonId)
        {
            var dbLesson = _context.Lessons.FirstOrDefault(c => c.LessonId == lessonId);
            if (dbLesson == null)
                throw new ArgumentNullException(nameof(dbLesson));

            return dbLesson;
        }
    }
}