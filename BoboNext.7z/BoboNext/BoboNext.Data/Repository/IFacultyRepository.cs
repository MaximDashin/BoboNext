﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface IFacultyRepository
    {
        IEnumerable<Faculty> Faculties { get; }

        void AddFaculty(Faculty faculty);
        void EditFaculty(Faculty faculty);
        void DeleteFaculty(int facultyId);
        Faculty GetFacultyById(int facultyId);

        
    }
}