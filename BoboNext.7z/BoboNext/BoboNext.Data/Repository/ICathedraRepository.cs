﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface ICathedraRepository
    {
        IEnumerable<Cathedra> Cathedras { get; }

        void AddCathedra(Cathedra cathedra);
        void EditCathedra(Cathedra cathedra);
        void DeleteCathedra(int cathedraId);
        Cathedra GetCathedraById(int cathedraId);


    }
}