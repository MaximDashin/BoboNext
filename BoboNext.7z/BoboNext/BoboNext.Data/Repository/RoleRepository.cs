﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.Authorize;
using Microsoft.AspNet.Identity.EntityFramework;

namespace BoboNext.Data.Repository
{
    public class RoleRepository : IRoleRepository
    {
        private readonly IDatabaseContext _context;

        public RoleRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Role> Roles => _context.Set<Role>();

        public void AddRole(Role role)
        {
            if (role == null)
                throw new ArgumentNullException(nameof(role));

            _context.Set<Role>().Add(role);

            _context.SaveChanges();
        }

        public void EditRole(Role role)
        {
            if (role == null)
                throw new ArgumentNullException(nameof(role));

            var dbItem = Roles.First(e => e.Id == role.Id);

            role.CopyWithChecking(dbItem,
                e => e.Description);

            //_context.Entry(role).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteRole(string roleId)
        {
            var dbRole = _context.Set<Role>().FirstOrDefault(c => c.Id == roleId);
            if (dbRole != null)
            {
                _context.Set<Role>().Remove(dbRole);
                //dbRole.IsDeleted = true;
                _context.SaveChanges();
            }
        }

        public IdentityRole GetRoleByValue(string roleName)
        {
            var dbRole = _context.Set<Role>().FirstOrDefault(c => c.Name == roleName);
            if (dbRole == null)
                throw new ArgumentNullException(nameof(dbRole));

            return dbRole;
        }
    }
}