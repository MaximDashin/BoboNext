﻿using System.Collections.Generic;
using BoboNext.Core.Domain.Authorize;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public interface IAccountRepository
    {
        IEnumerable<Account> Accounts { get; }

        void AddAccount(Account account);
        void EditAccount(Account account);
        void DeleteAccount(string accountId);
        Account GetAccountById(string accountId);
        Account GetAccountByName(string accountName);
        Account GetAccountFromAccountViewModel(AccountViewModel model);
        Account GetAccountFromRegistrationViewModel(RegistrationViewModel model);
        AccountViewModel GetAccountViewModelFromAccount(string accountId);

    }
}