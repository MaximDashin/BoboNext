﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BoboNext.Core.Domain.University;
using BoboNext.Core.ViewModels;

namespace BoboNext.Data.Repository
{
    public class CathedraRepository : ICathedraRepository
    {
        private readonly IDatabaseContext _context;

        public CathedraRepository(IDatabaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Cathedra> Cathedras => _context.Cathedras.Where(c => !c.IsDeleted);

        public void AddCathedra(Cathedra cathedra)
        {
            if (cathedra == null)
                throw new ArgumentNullException(nameof(cathedra));

            _context.Cathedras.Add(cathedra);

            _context.SaveChanges();
        }

        public void EditCathedra(Cathedra cathedra)
        {
            if (cathedra == null)
                throw new ArgumentNullException(nameof(cathedra));

            var dbItem = Cathedras.First(e => e.CathedraId == cathedra.CathedraId);

            cathedra.CopyWithChecking(dbItem,
                e => e.CathedraName,
                e => e.FacultyId);

            //_context.Entry(cathedra).State = EntityState.Modified;

            _context.SaveChanges();
        }

        public void DeleteCathedra(int cathedraId)
        {
            var dbCathedra = _context.Cathedras.FirstOrDefault(c => c.CathedraId == cathedraId);
            if (dbCathedra != null)
            {
                dbCathedra.IsDeleted = true;
            }
            _context.SaveChanges();
        }

        public Cathedra GetCathedraById(int cathedraId)
        {
            var dbCathedra = _context.Cathedras.FirstOrDefault(c => c.CathedraId == cathedraId);
            if (dbCathedra == null)
                throw new ArgumentNullException(nameof(dbCathedra));

            return dbCathedra;

        }

    }
}
