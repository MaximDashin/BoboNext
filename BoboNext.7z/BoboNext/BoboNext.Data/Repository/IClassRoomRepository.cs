﻿using System.Collections.Generic;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data.Repository
{
    public interface IClassRoomRepository
    {
        IEnumerable<ClassRoom> ClassRooms { get; }

        void AddClassRoom(ClassRoom classRoom);
        void EditClassRoom(ClassRoom classRoom);
        void DeleteClassRoom(int classRoomId);
        ClassRoom GetClassRoomById(int classRoomId);
        IEnumerable<ClassRoom> Search(string classRoom, string university);
    }
}