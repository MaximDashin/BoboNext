﻿using System.Data.Entity;
using BoboNext.Core.Domain.Authorize;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.Domain.System;
using BoboNext.Core.Domain.University;
using Microsoft.AspNet.Identity.EntityFramework;

namespace BoboNext.Data
{
    public class DatabaseContext : IdentityDbContext<Account>, IDatabaseContext  /*DbContext,*/
    {
        public DatabaseContext() : base("name=DefaultConnection")
        {
        }

        public DbSet<City> Cities { get; set; }
        public DbSet<University> Universities { get; set; }
        public DbSet<Faculty> Faculties { get; set; }
        public DbSet<Speciality> Specialities { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Lesson> Lessons { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Term> Terms { get; set; }
        public DbSet<ClassRoom> ClassRooms { get; set; }
        public DbSet<Schedule> Schedules { get; set; }
        public DbSet<Cathedra> Cathedras { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<LogItem> LogItems { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            

            modelBuilder.Entity<City>()
               .HasKey(e => e.CityId)
               .HasMany(e => e.Universities)
               .WithRequired(e => e.City)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<University>()
               .HasKey(e => e.UniversityId)
               .HasMany(e => e.Schedules)
               .WithRequired(e => e.University)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<University>()
               .HasMany(e => e.Terms)
               .WithRequired(e => e.University)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<University>()
               .HasMany(e => e.ClassRooms)
               .WithRequired(e => e.University)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<University>()
               .HasMany(e => e.Faculties)
               .WithRequired(e => e.University)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<University>()
               .HasMany(e => e.Subjects)
               .WithRequired(e => e.University)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<University>()
                .HasMany(e => e.Lessons)
                .WithRequired(e => e.University)
                .WillCascadeOnDelete(false);


            modelBuilder.Entity<Cathedra>()
                .HasKey(e => e.CathedraId)
                .HasMany(e => e.Teachers)
                .WithRequired(e => e.Cathedra)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Faculty>()
                .HasKey(e => e.FacultyId)
                .HasMany(e => e.Specialities)
                .WithRequired(e => e.Faculty)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Faculty>()
                .HasMany(e => e.Cathedras)
                .WithRequired(e => e.Faculty)
                .WillCascadeOnDelete(false);


            modelBuilder.Entity<Speciality>()
                .HasKey(e => e.SpecialityId)
                .HasMany(e => e.Groups)
                .WithRequired(e => e.Speciality)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Schedule>()
                .HasKey(e => e.ScheduleId)
                .HasMany(e => e.Lessons)
                .WithMany(e => e.Schedules);

            modelBuilder.Entity<Subject>()
                .HasKey(e => e.SubjectId)
                .HasMany(e => e.Lessons)
                .WithRequired(e => e.Subject)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ClassRoom>()
                .HasKey(e => e.ClassRoomId)
                .HasMany(e => e.Lessons)
                .WithRequired(e => e.ClassRoom)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Teacher>()
                .HasKey(e => e.TeacherId)
                .HasMany(e => e.Lessons)
                .WithRequired(e => e.Teacher)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Group>()
                .HasKey(e=>e.GroupId)
                .HasMany(e => e.Lessons)
                .WithMany(e => e.Groups);

            modelBuilder.Entity<Group>()
                .HasMany(e => e.Students)
                .WithRequired(e => e.Group)
                .WillCascadeOnDelete(false);



            modelBuilder.Entity<Teacher>()
                .HasOptional(e => e.Account)
                .WithMany()
                .HasForeignKey(e => e.AccountId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Account>()
                .HasOptional(e => e.Teacher)
                .WithMany()
                .HasForeignKey(e => e.TeacherId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Faculty>()
                .HasOptional(e => e.Account)
                .WithMany()
                .HasForeignKey(e => e.AccountId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Account>()
                .HasOptional(e => e.Faculty)
                .WithMany()
                .HasForeignKey(e => e.FacultyId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Account>()
                .HasOptional(e => e.Student)
                .WithRequired(e => e.Account);

            modelBuilder.Entity<Student>()
                .HasKey(e => e.AccountId);

        }
        //Initial
        IDbSet<TEntity> IDatabaseContext.Set<TEntity>() => Set<TEntity>();

        ///// <summary> 
        ///// Открытие новой транзакции 
        ///// </summary> 
        ///// <returns></returns> 
        //DbContextTransaction IDatabaseContext.BeginTransaction() => Database.BeginTransaction();

        ///// <summary>
        ///// Текущая транзакция к БД
        ///// </summary>
        //DbContextTransaction IDatabaseContext.CurrentTransaction => Database.CurrentTransaction;

        /// <summary> 
        /// Фабричный метод создания контекста 
        /// </summary> 
        /// <returns></returns> 
        public static DatabaseContext Create() => new DatabaseContext();

    }
}
