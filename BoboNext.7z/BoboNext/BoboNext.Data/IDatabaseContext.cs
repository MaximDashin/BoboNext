﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Threading.Tasks;
using BoboNext.Core.Domain.Lesson;
using BoboNext.Core.Domain.System;
using BoboNext.Core.Domain.University;

namespace BoboNext.Data
{
    public interface IDatabaseContext
    {
        IDbSet<TEntity> Set<TEntity>() where TEntity : class;

        DbSet<City> Cities { get; set; }
        DbSet<University> Universities { get; set; }
        DbSet<Faculty> Faculties { get; set; }
        DbSet<Speciality> Specialities { get; set; }
        DbSet<Group> Groups { get; set; }
        DbSet<Lesson> Lessons { get; set; }
        DbSet<Subject> Subjects { get; set; }
        DbSet<Term> Terms { get; set; }
        DbSet<ClassRoom> ClassRooms { get; set; }
        DbSet<Schedule> Schedules { get; set; }
        DbSet<Cathedra> Cathedras { get; set; }
        DbSet<Teacher> Teachers { get; set; }
        DbSet<Student> Students { get; set; }
        DbSet<LogItem> LogItems { get; set; }

        int SaveChanges();

        Task<int> SaveChangesAsync();

        DbEntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;

    }
}